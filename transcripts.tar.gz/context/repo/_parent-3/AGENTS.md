# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## make.fun watch — pelajaran 2026-11-23
- Endpoint daftar default `/api/competitions` hanya mengembalikan 50 item pertama (terurut lama→baru) — bounty baru tidak terlihat tanpa `limit=200` + paginasi cursor.
- Field `entryFeesUsd` di tampilan daftar adalah TOTAL fee terkumpul, bukan fee per akun — fee per akun dibaca via endpoint per-kompetisi (`entryFeeUsd`).

## Telegram bots — JANGAN pernah start manual (pelajaran 2026-11-14)
- Bot toko Gram Ecer (@GramEcer_bot) jalan di bawah **systemd `gramecer-bot.service`** (sejak 2026-11-12 ~11:36 WIB; `Restart=always`, `WorkingDirectory=~/workspace/telegram-shop-bot`, `PYTHONPATH=~/.local/lib/python3.12/site-packages`, proxy env di unit). Bot lain juga punya service sendiri (`cryptokom-pricebot`, `eth-alert-bot`, `gram-ecer-cs-bot`).
- **Restart HANYA via `systemctl restart gramecer-bot.service`.** JANGAN `setsid nohup python3 -u bot.py` — itu membuat proses DUPLIKAT yang berebut getUpdates dengan service (update terbelah acak antara kode lama dan baru), dan duplikatnya mati sendiri karena konflik 409. Tiga kali restart manual (2026-11-12 s.d. 2026-11-14) semuanya mati begitu — sementara service-nya hidup terus. Kalau `pgrep` menunjukkan 2 proses bot.py di direktori yang sama, yang satu adalah duplikat manual: bunuh duplikatnya, restart service-nya.
- Setelah ganti VM, service bisa hilang dari /etc (ephemeral) — skrip `check_bots.sh` menyalin ulang unit dari home + daemon-reload + enable. Cek `systemctl is-active gramecer-bot.service` dulu sebelum mengira bot mati.
- Library pip `--user` (pytoniq, qrcode, opencv) tinggal di `~/.local/lib/python3.12/site-packages` — hilang tiap ganti VM, pasang ulang bila perlu; kode bot harus punya fallback kalau library tidak ada (mis. QRIS dinamis gagal -> QRIS statis).
- Setelah ganti VM, numpy sistem bisa jadi 2.x sementara matplotlib sistem 3.6.3 (dibangun untuk numpy 1.x) — gambar chart bot harga gagal total ("gambar chart tidak terbentuk"). Perbaikan terverifikasi 2026-11-16: `pip install --break-system-packages "numpy==1.26.4"` (upgrade matplotlib gagal karena kiwisolver paket Debian tak bisa di-uninstall). cv2 tetap jalan dengan numpy 1.26.4 meski pip protes soal konflik. Cek: `python3 -c "import bot; print(bot.make_chart_image('bitcoin', days=1))"` di ~/workspace/crypto-price-bot.
